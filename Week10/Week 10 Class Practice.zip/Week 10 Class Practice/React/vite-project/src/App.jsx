import React from "react";
import "./App.css";

function App() {
  return (
    <>
      {/* 
Starting

*/}
      <h1>This is heading 1 </h1>
      <h2>This is heading 2 </h2>
      {/* Ending Point
       */}
    </>
  );
}

export default App;
